This package implements the Fork Fulkerson algorithm to find the path with the max flow in a network.
