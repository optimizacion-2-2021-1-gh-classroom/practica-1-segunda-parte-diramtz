This package implements the Fork Fulkerson algorithm to find the maximum posible flow in a network.

The Ford-Fulkerson method answers the question of given a network with vertices and edges between those vertices that have certain weights, how much "flow" can the network process at a time?
